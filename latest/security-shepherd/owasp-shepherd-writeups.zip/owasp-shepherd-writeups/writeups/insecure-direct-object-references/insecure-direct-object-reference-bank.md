# Insecure Direct Object Reference Bank Challenge

## Description
This challenge simulates a banking application vulnerable to Insecure Direct Object Reference (IDOR) attacks. The vulnerability allows unauthorized access to other users' accounts by manipulating account identifiers in transactions. The result key is hidden in another user's account information.

## Solution
This challenge demonstrates a critical IDOR vulnerability in a banking application where account numbers are directly referenced in transactions without proper authorization checks. By creating an account and manipulating the transaction parameters, we can access other users' accounts.

## Steps to Reproduce

### Step 1
Register and log in to your account. After that, send a sample transfer to a random account to understand the request structure.

![](/writeups/assets/images/idor/idor-1-1.jpg)

### Step 2
Intercept and copy the transaction request from your browser's network tab. Modify the copied curl request to fuzz account numbers from 0 to 100 by changing the `senderAccountNumber` parameter. You only need to keep the essential headers and can remove the others.

```bash
for i in {0..100}; do
 echo "Testing senderAccountNumber=$i"
 curl 'https://localhost/challenges/1f0935baec6ba69d79cfb2eba5fdfa6ac5d77fadee08585eb98b130ec524d00cTransfer' \
   -X POST \
   -H 'Content-Type: application/x-www-form-urlencoded' \
   -H 'Cookie: JSESSIONID=C0928A503DFBE82CA1722040C34C9BD4; token=-54856602110500099982166392798520603901' \
   --data-raw "senderAccountNumber=$i&recieverAccountNumber=2&transferAmount=10000000" -k
done
```

### Step 3
Log out and log back in to retrieve the result key that was exposed during the fuzzing process.

![](/writeups/assets/images/idor/idor-1-2.jpg)

## Exploit
This vulnerability is a classic example of Insecure Direct Object Reference in a financial application. The exploit works because:

1. Account numbers are directly exposed in the transaction parameters
2. There are no proper authorization checks to verify that the user has access to the specified accounts
3. The application processes transactions based solely on the provided account numbers
4. Account numbers follow a predictable sequence, making them easy to guess or fuzz

The vulnerability allows an attacker to:
1. Access any account by simply changing the account number parameters
2. Transfer funds from unauthorized accounts
3. View sensitive account information

## Impact
IDOR vulnerabilities in banking applications can have severe consequences:

1. **Financial Loss**: Unauthorized transfers can drain user accounts
2. **Privacy Violations**: Access to other users' financial information
3. **Identity Theft**: Exposure of personal and financial data
4. **Regulatory Compliance Issues**: Violation of financial industry regulations
5. **Reputational Damage**: Loss of customer trust and confidence
6. **Legal Liability**: Potential lawsuits and regulatory penalties

## Mitigation
To prevent IDOR vulnerabilities in financial applications:

1. **Implement Proper Access Controls**: Verify that users are authorized to access specific accounts before processing transactions
2. **Use Indirect Object References**: Map user-friendly identifiers to internal object references using mapping tables
3. **Apply the Principle of Least Privilege**: Ensure users can only access accounts they own or are authorized to manage
4. **Implement Strong Session Management**: Bind transactions to specific user sessions
5. **Add Multi-Factor Authentication**: Require additional verification for sensitive operations
6. **Log and Monitor Access**: Track account access patterns to detect suspicious activity
7. **Regular Security Testing**: Conduct thorough testing for IDOR vulnerabilities during development and maintenance

---

[← Previous](./insecure-direct-object-reference-challenge-2.md) | [Next →](./insecure-direct-object-reference-challenge-1.md)


