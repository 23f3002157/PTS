# Insecure Direct Object Reference Challenge 2

## Description
The result key for this challenge is stored in a private message for a user that is not listed in the visible user directory. This challenge is similar to the previous IDOR challenge but uses MD5-hashed user IDs instead of plain numeric IDs, demonstrating that obfuscation alone is not sufficient to prevent IDOR vulnerabilities.

## Solution
This challenge is similar to the previous IDOR challenge but with an additional layer of obfuscation. User IDs are converted to MD5 hashes, but since there are no proper access controls, we can still enumerate users by hashing sequential numbers and testing the resulting hashes.

## Steps to Reproduce

### Step 1
Copy the request structure as done in the previous challenge. This will be used to create our enumeration script.

![](/writeups/assets/images/idor/idor-3-1.jpg)

### Step 2
Create a bash script to fuzz user IDs by converting numbers 1 through 100 to their MD5 hashes. Update this script with your session information. The script will automatically extract and display the result key when found.

```bash
for i in {1..100}; do 
hash=$(echo -n "$i" | md5sum | awk '{print $1}')
curl -s 'https://localhost/challenges/vc9b78627df2c032ceaf7375df1d847e47ed7abac2a4ce4cb6086646e0f313a4' \
  -X POST \
  -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:142.0) Gecko/20100101 Firefox/142.0' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'Cookie: JSESSIONID=C0928A503DFBE82CA1722040C34C9BD4; token=-54856602110500099982166392798520603901' \
  --data-raw "userId%5B%5D=$hash" -k | sed -n 's/.*Result Key is <a>\([^<]*\)<\/a>.*/\1/p'
done
```

### Step 3
Run the script and wait for it to discover the user ID hash containing the result key.

## Exploit
This vulnerability demonstrates that simple obfuscation techniques like hashing are insufficient to prevent IDOR attacks. The exploit works because:

1. Although user IDs are MD5-hashed, they are still directly referenced in the `userId[]` parameter
2. There are no access controls to verify that the requesting user should have access to the specified user's data
3. The hashing algorithm is known (MD5), so attackers can generate hashes for sequential user IDs
4. The application returns sensitive information when a valid user ID hash is provided

The vulnerability allows an attacker to:
1. Access private messages of any user by generating and testing MD5 hashes of sequential user IDs
2. Enumerate all users in the system by systematically testing hashed user IDs
3. Extract sensitive information that should be protected

This shows that security through obscurity is not an effective defense mechanism.

## Impact
IDOR vulnerabilities with hashed identifiers can still lead to serious security and privacy issues:

1. **Unauthorized Data Access**: Exposure of private user information and messages
2. **Privacy Violations**: Access to personal data without consent
3. **Data Breach Potential**: Large-scale exposure of user information
4. **Compliance Issues**: Violation of data protection regulations (GDPR, CCPA, etc.)
5. **Loss of User Trust**: Damage to the organization's reputation
6. **Potential Legal Consequences**: Regulatory penalties and lawsuits

## Mitigation
To prevent IDOR vulnerabilities, even when using obfuscation:

1. **Implement Proper Access Controls**: Verify that users are authorized to access requested resources regardless of identifier format
2. **Use Indirect Object References**: Employ mapping tables or tokens instead of exposing any form of direct object identifiers
3. **Apply the Principle of Least Privilege**: Ensure users can only access data they own or are authorized to view
4. **Validate User Permissions**: Check user permissions on the server side for every request
5. **Implement Rate Limiting**: Prevent automated enumeration attacks
6. **Log and Monitor Access**: Track access patterns to detect unauthorized attempts
7. **Regular Security Testing**: Include IDOR testing in security assessments with various identifier formats
8. **Avoid Security Through Obscurity**: Don't rely on obfuscation as a primary security mechanism

---

[← Previous](./insecure-direct-object-reference-challenge-1.md)

