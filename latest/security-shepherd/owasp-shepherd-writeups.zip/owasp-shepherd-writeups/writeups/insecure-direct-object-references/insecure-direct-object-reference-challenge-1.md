# Insecure Direct Object Reference Challenge 1

## Description
The result key for this challenge is stored in a private message for a user that is not listed in the visible user directory. This challenge demonstrates how IDOR vulnerabilities can expose sensitive information by allowing unauthorized access to user data through direct manipulation of user identifiers.

## Solution
This challenge can be solved by exploiting an Insecure Direct Object Reference vulnerability. Since there are no protections against IDOR, we can fuzz user ID numbers to access private messages belonging to other users.

## Steps to Reproduce

### Step 1
Open your browser's network tab and trigger the `Show This Profile` action once. Then click `Copy as a cURL` to capture the request structure.

![](/writeups/assets/images/idor/idor-2-1.jpg)

### Step 2
Create a bash script to fuzz user IDs from 1 to 100. Update this request with your session information. The script will automatically extract and display the result key when found.

```bash
for i in {1..100}; do
curl -s 'https://localhost/challenges/o9a450a64cc2a196f55878e2bd9a27a72daea0f17017253f87e7ebd98c71c98c' \
  -X POST \
  -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:142.0) Gecko/20100101 Firefox/142.0' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'Cookie: JSESSIONID=C0928A503DFBE82CA1722040C34C9BD4; token=-54856602110500099982166392798520603901' \
  --data-raw "userId%5B%5D=$i" -k  | sed -n 's/.*Result Key is <a>\([^<]*\)<\/a>.*/\1/p'
done
```

### Step 3
Run the script and wait for it to discover the user ID containing the result key.

## Exploit
This vulnerability is a straightforward Insecure Direct Object Reference where user IDs are directly exposed in the request parameters without proper authorization checks. The exploit works because:

1. User IDs are directly referenced in the `userId[]` parameter
2. There are no access controls to verify that the requesting user should have access to the specified user's data
3. User IDs follow a simple sequential pattern, making them easy to guess or fuzz
4. The application returns sensitive information when a valid user ID is provided

The vulnerability allows an attacker to:
1. Access private messages of any user by simply changing the user ID parameter
2. Enumerate all users in the system by systematically testing user IDs
3. Extract sensitive information that should be protected

## Impact
IDOR vulnerabilities can lead to serious security and privacy issues:

1. **Unauthorized Data Access**: Exposure of private user information and messages
2. **Privacy Violations**: Access to personal data without consent
3. **Data Breach Potential**: Large-scale exposure of user information
4. **Compliance Issues**: Violation of data protection regulations (GDPR, CCPA, etc.)
5. **Loss of User Trust**: Damage to the organization's reputation
6. **Potential Legal Consequences**: Regulatory penalties and lawsuits

## Mitigation
To prevent IDOR vulnerabilities:

1. **Implement Proper Access Controls**: Verify that users are authorized to access requested resources
2. **Use Indirect Object References**: Employ mapping tables or tokens instead of exposing direct object identifiers
3. **Apply the Principle of Least Privilege**: Ensure users can only access data they own or are authorized to view
4. **Validate User Permissions**: Check user permissions on the server side for every request
5. **Implement Rate Limiting**: Prevent automated enumeration attacks
6. **Log and Monitor Access**: Track access patterns to detect unauthorized attempts
7. **Regular Security Testing**: Include IDOR testing in security assessments
8. **Follow Security Best Practices**: Adopt secure coding standards and review practices

---

[Next →](./insecure-direct-object-reference-challenge-2.md)

