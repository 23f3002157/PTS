# SQL Injection Escaping Challenge

## Description
To complete this challenge, you must exploit an SQL injection flaw in the following form to find the result key. The developer of this level has attempted to stop SQL Injection attacks by escaping apostrophes so the database interpreter will know not to pay attention to user submitted apostrophes.

## Solution
This challenge demonstrates that simple character escaping is not sufficient to prevent SQL injection attacks. The payload uses a backslash-escaped apostrophe to bypass the developer's protection mechanism.

## Steps to Reproduce

### Step 1
Navigate to the challenge page and locate the input field where the SQL injection can be exploited.

### Step 2
Enter the payload \' or 1=1-- into the input field and submit the form.

## Exploit
This vulnerability shows that basic character escaping is insufficient to prevent SQL injection attacks. The developer attempted to prevent SQL injection by escaping apostrophes, but the payload \' or 1=1-- works because:

1. The backslash escapes the apostrophe, so the application's escaping function may not recognize it as a quote to escape
2. The `or 1=1` creates a condition that always evaluates to true
3. The `--` comments out the rest of the original query

Payload: `\' or 1=1--`

![](/writeups/assets/images/injection/sqli-escape.jpg)

This demonstrates that simple character escaping can be bypassed, and more robust protection mechanisms are needed.

## Impact
This vulnerability allows attackers to bypass weak protection mechanisms and exploit SQL injection vulnerabilities, potentially leading to unauthorized data access or administrative privileges.

## Mitigation
1. Use parameterized queries or prepared statements instead of string concatenation
2. Implement comprehensive input validation and sanitization
3. Use allowlists rather than denylists for input validation
4. Employ web application firewalls (WAF) to detect and block injection attempts
5. Regularly review and update security measures to address new bypass techniques

---

[← Previous](./sql-injection-7.md) | [Next →](./sql-injection-stored-procedure.md)


