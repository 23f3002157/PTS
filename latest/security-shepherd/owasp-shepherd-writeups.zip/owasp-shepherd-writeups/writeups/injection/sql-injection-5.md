# SQL Injection 5

## Description
To complete this challenge, you must exploit an SQL injection flaw in the coupon code validation to extract a valid coupon code from the database.

## Solution
This challenge requires intercepting and modifying the request to exploit a SQL injection vulnerability in the coupon code parameter. The payload retrieves the valid coupon code from the database using a UNION-based injection technique.

## Steps to Reproduce

### Step 1
Navigate to the challenge page and click the `Place Order` button.

![](/writeups/assets/images/injection/sqli-5.jpg)

### Step 2
Open your browser's developer console and intercept the request. Replace the `couponCode` parameter value with the SQL injection payload. Don't forget to append `VipCouponCheck` to the URL.

Payload: `' union select itemId,percentOff,CONCAT('This is the couponCode: ', couponCode, ' ') from vipCoupons where itemId=2; --`

![](/writeups/assets/images/injection/sqli-5-2.jpg)

### Step 3
After sending the modified request, the response will contain the valid coupon code.

The coupon code looks like this: `spcil/|Pse3cr3etCouponStu.f4rU176`

![](/writeups/assets/images/injection/sqli-5-3.jpg)

## Exploit
This vulnerability uses a UNION-based SQL injection technique to extract sensitive data from the database. The payload works by:

1. Using `'` to break out of the quoted string in the SQL query
2. Adding `union select` to combine the original query with a new one that retrieves data from the `vipCoupons` table
3. Selecting `itemId`, `percentOff`, and using `CONCAT` to format the output with the actual coupon code
4. Filtering for `itemId=2` to get the specific coupon
5. Using `;--` to comment out the rest of the original query

Payload: `' union select itemId,percentOff,CONCAT('This is the couponCode: ', couponCode, ' ') from vipCoupons where itemId=2; --`

## Impact
This vulnerability allows attackers to extract sensitive coupon codes that may provide discounts or access to exclusive features. In a real-world scenario, similar vulnerabilities could expose sensitive business data, customer information, or financial records.

## Mitigation
1. Use parameterized queries or prepared statements for all database interactions
2. Implement proper input validation and sanitization for all user-supplied data
3. Apply the principle of least privilege for database accounts
4. Use web application firewalls (WAF) to detect and block injection attempts
5. Regularly audit applications for injection vulnerabilities

---

[← Previous](./sql-injection-4.md) | [Next →](./sql-injection-6.md)

