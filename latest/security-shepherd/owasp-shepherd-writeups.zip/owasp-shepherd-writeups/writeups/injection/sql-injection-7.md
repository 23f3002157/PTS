# SQL Injection 7

## Description
This challenge requires bypassing a SQL injection vulnerability in the `subEmail` parameter to gain unauthorized access.

## Solution
This challenge involves exploiting a SQL injection vulnerability in the subscription email field. The payload uses URL-encoded characters to bypass filters and inject malicious SQL code.

## Steps to Reproduce

### Step 1
Navigate to the challenge page and locate the subscription form with the vulnerable `subEmail` parameter.

### Step 2
Enter the following payload into the subscription form:

Payload: `subEmail='%0aor%0a1%3D1%0aor%0a'23'!='sahin%40sahinyes.com&subPassword=qwer`

![](/writeups/assets/images/injection/sqli-7.jpg)

## Exploit
This vulnerability uses URL-encoded characters to bypass input filters and exploit a SQL injection in the `subEmail` parameter. The payload works as follows:

1. `%0a` represents a newline character, used to break up the injection and bypass simple filters
2. `or` introduces alternative conditions
3. `1%3D1` is URL-encoded for `1=1`, a condition that always evaluates to true
4. `%0a` again uses a newline character
5. `or` introduces another alternative condition
6. `'23'!='sahin%40sahinyes.com` creates another condition that always evaluates to true
7. The payload effectively bypasses authentication by creating conditions that always return true

Decoded payload: `subEmail='
or
1=1
or
'23'!='sahin@sahinyes.com&subPassword=qwer`

## Impact
This vulnerability allows attackers to bypass authentication mechanisms and gain unauthorized access to the application. The use of newline characters to bypass filters demonstrates how attackers can evade simple security measures.

## Mitigation
1. Use parameterized queries or prepared statements for all database interactions
2. Implement comprehensive input validation that handles various encodings
3. Use web application firewalls (WAF) to detect and block injection attempts
4. Employ proper output encoding when displaying user input
5. Regularly test applications with various encoding techniques to identify bypass opportunities

---

[← Previous](./sql-injection-6.md) | [Next →](./sql-injection-escaping.md)