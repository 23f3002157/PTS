# SQL Injection 1

## Description
To complete this challenge, you must exploit an SQL injection flaw in the following form to find the result key.

## Solution
The SQL injection payload for this challenge is `" or 1#`.

This payload works by breaking out of the quoted string in the SQL query and appending a condition that always evaluates to true (`1`), effectively bypassing the authentication mechanism.

## Steps to Reproduce

### Step 1
Navigate to the challenge page and locate the input field where the SQL injection can be exploited.

### Step 2
Enter the payload `" or 1#` into the input field and submit the form.

![](/writeups/assets/images/injection/sqli-1.jpg)

## Exploit
The vulnerability exists because the application directly concatenates user input into SQL queries without proper sanitization or parameterization. The payload `" or 1#` exploits this by:

1. The `"` character closes the quoted string in the SQL query
2. `or 1` adds a condition that always evaluates to true
3. `#` comments out the rest of the original query

Payload: `" or 1#`

## Impact
This vulnerability allows an attacker to bypass authentication mechanisms and potentially access sensitive data or administrative functions without proper credentials.

## Mitigation
1. Use parameterized queries or prepared statements instead of string concatenation
2. Implement proper input validation and sanitization
3. Apply the principle of least privilege for database accounts
4. Use web application firewalls (WAF) to detect and block injection attempts

---

[← Previous](./nosql-injection-one.md) | [Next →](./sql-injection-2.md)



