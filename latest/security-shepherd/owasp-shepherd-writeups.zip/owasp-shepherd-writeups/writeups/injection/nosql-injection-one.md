# NoSQL Injection One

## Description
To complete this challenge, you must exploit a NoSQL injection flaw in the following form to find the result key. Please enter the Customer Id of the user that you want to look up.

## Solution
This challenge contains a NoSQL injection vulnerability in the `theGamerName` parameter. The payload uses JavaScript code injection to bypass the query logic and retrieve all user data.

## Steps to Reproduce

### Step 1

The `theGamerName` parameter has a NoSQL injection vulnerability. To exploit it, set the value to `'; return(true); var foo='bar` to dump users' data.

![](/writeups/assets/images/injection/nosql-1.jpg)

### Step 2

Submit the form with the malicious payload to retrieve the user data.

### Step 3

Extract the result key from the retrieved data.

## Exploit
This vulnerability is a NoSQL injection that exploits the MongoDB JavaScript expression evaluation feature. The payload works by:

1. The `';` closes the original query string
2. `return(true);` forces the query to return true, matching all documents
3. `var foo='bar` is additional JavaScript code that completes the expression

Payload: `'; return(true); var foo='bar`

This type of injection is possible when:
1. Applications directly incorporate user input into NoSQL queries
2. The NoSQL database (like MongoDB) supports JavaScript expressions in queries
3. User input is not properly sanitized or validated

## Impact
This vulnerability allows attackers to:
1. Bypass query logic and retrieve unauthorized data
2. Extract all user records from the database
3. Potentially access sensitive information such as personal details or credentials

## Mitigation
1. Use parameterized queries or prepared statements even for NoSQL databases
2. Implement proper input validation and sanitization
3. Disable JavaScript evaluation in NoSQL queries where possible
4. Apply the principle of least privilege for database accounts
5. Regularly audit NoSQL queries for potential injection points
6. Use allowlists for input validation where possible

---

[Next →](./sql-injection-1.md)

