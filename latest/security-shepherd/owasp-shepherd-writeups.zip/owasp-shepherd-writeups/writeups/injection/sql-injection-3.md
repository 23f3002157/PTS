# SQL Injection 3

## Description
To complete this challenge, you must exploit an SQL injection flaw in the following form to find the result key.

## Solution
The SQL injection payload for this challenge is `Mary MArtin' Union select CreditCardNumber from customers where customerName='mary martin`.

This payload uses a UNION-based SQL injection technique to extract sensitive data from another table.

## Steps to Reproduce

### Step 1
Navigate to the challenge page and locate the input field where the SQL injection can be exploited.

### Step 2
Enter the payload `Mary MArtin' Union select CreditCardNumber from customers where customerName='mary martin` into the input field and submit the form.

![](/writeups/assets/images/injection/sqli-3.jpg)

## Exploit
This vulnerability uses a UNION-based SQL injection technique to extract data from the database. The payload works by:

1. Starting with a valid input (`Mary MArtin`) to pass any initial validation
2. Using `'` to break out of the quoted string in the SQL query
3. Adding `Union select CreditCardNumber from customers where customerName='mary martin` to append a second query that retrieves credit card numbers
4. This causes the application to return both the original query results and the sensitive credit card data

Payload: `Mary MArtin' Union select CreditCardNumber from customers where customerName='mary martin`

## Impact
This vulnerability allows attackers to extract sensitive data from the database, including credit card numbers and other personal information, which could be used for financial fraud or identity theft.

## Mitigation
1. Use parameterized queries or prepared statements
2. Implement proper input validation and sanitization
3. Apply the principle of least privilege for database accounts
4. Regularly audit database queries for potential injection points
5. Encrypt sensitive data at rest and in transit

---

[← Previous](./sql-injection-2.md) | [Next →](./sql-injection-4.md)



