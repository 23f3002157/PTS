# SQL Injection 6

## Description
To obtain the result key to this challenge, you must obtain Brendan's answer to his security question.

## Solution
This challenge contains a SQL injection vulnerability in the `pinNumber` parameter. The payload uses a UNION-based injection to extract Brendan's security question answer from the database.

## Steps to Reproduce

### Step 1
Navigate to the challenge page and locate the input field for the `pinNumber`.

### Step 2
Enter the SQL injection payload into the `pinNumber` field and submit the form.

Payload: `\x27\x20UNION\x20SELECT\x20userAnswer\x20FROM\x20users\x20WHERE\x20userName\x20\x3D\x20\x27Brendan\x27\x3B\x20--\x20`

![](/writeups/assets/images/injection/sqli-6.jpg)

## Exploit
This vulnerability uses a UNION-based SQL injection technique to extract sensitive data from the database. The payload is URL-encoded and works as follows:

1. `\x27` is the URL-encoded representation of a single quote (`'`)
2. `\x20` is the URL-encoded representation of a space
3. The payload translates to: `' UNION SELECT userAnswer FROM users WHERE userName = 'Brendan'; -- `
4. This breaks out of the original query and appends a new one that retrieves Brendan's security question answer
5. The `; --` comments out the rest of the original query

Decoded payload: `' UNION SELECT userAnswer FROM users WHERE userName = 'Brendan'; -- `

## Impact
This vulnerability allows attackers to extract sensitive security question answers, which could be used to bypass account recovery mechanisms and gain unauthorized access to user accounts.

## Mitigation
1. Use parameterized queries or prepared statements for all database interactions
2. Implement proper input validation to reject SQL metacharacters
3. Apply the principle of least privilege for database accounts
4. Use web application firewalls (WAF) to detect and block injection attempts
5. Regularly audit applications for injection vulnerabilities

---

[← Previous](./sql-injection-5.md) | [Next →](./sql-injection-7.md)