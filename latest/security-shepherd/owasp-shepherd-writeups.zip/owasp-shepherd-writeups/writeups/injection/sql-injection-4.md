# SQL Injection 4

## Description
To complete this challenge, you must exploit an SQL injection flaw in the following form to find the result key.

## Solution
This challenge requires SQL injection on both the username and password fields. The payloads are:
- Username: `\`
- Password: ` or username="admin";-- -`

This technique exploits the authentication mechanism by commenting out the password check and forcing the query to match the admin user.

## Steps to Reproduce

### Step 1
Navigate to the challenge page and locate the login form.

### Step 2
Enter the following payloads:
- Username: `\`
- Password: ` or username="admin";-- -`

### Step 3
Submit the form to exploit the SQL injection vulnerability.

![](/writeups/assets/images/injection/sqli-4.jpg)

## Exploit
This vulnerability exploits the authentication mechanism through SQL injection in both input fields. The payloads work as follows:

1. Username field (`\`): This may be used to escape the first quote or cause a syntax error that is handled by the application
2. Password field (` or username="admin";-- -`): This payload:
   - Uses `or` to introduce an alternative condition
   - `username="admin"` specifies that we want to match the admin user
   - `;-- -` comments out the rest of the original query, effectively removing the password verification

Payloads:
- Username: `\`
- Password: ` or username="admin";-- -`

## Impact
This vulnerability allows attackers to bypass authentication and gain administrative access to the application, potentially leading to complete compromise of the system and access to all sensitive data.

## Mitigation
1. Use parameterized queries or prepared statements for all database interactions
2. Implement proper input validation to reject SQL metacharacters
3. Apply account lockout mechanisms after failed login attempts
4. Use multi-factor authentication for privileged accounts
5. Regularly review and test authentication mechanisms for vulnerabilities

---

[← Previous](./sql-injection-3.md) | [Next →](./sql-injection-5.md)
