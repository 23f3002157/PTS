# SQL Injection 2

## Description
To complete this challenge, you must exploit an SQL injection flaw in the following form to find the result key.

## Solution
The SQL injection payload for this challenge is `'or'1'!='sahin@sahinyes.com`.

This payload exploits a logical condition that always evaluates to true, bypassing the intended query logic.

## Steps to Reproduce

### Step 1
Navigate to the challenge page and locate the input field where the SQL injection can be exploited.

### Step 2
Enter the payload `'or'1'!='sahin@sahinyes.com` into the input field and submit the form.

![](/writeups/assets/images/injection/sqli-2.jpg)

## Exploit
This vulnerability occurs because the application directly incorporates user input into SQL queries without proper sanitization. The payload `'or'1'!='sahin@sahinyes.com` works by:

1. The `'` character breaks out of the quoted string in the SQL query
2. `or` introduces an alternative condition
3. `'1'!='sahin@sahinyes.com` creates a condition that always evaluates to true (since '1' is never equal to an email address)
4. This causes the query to return all records, bypassing the intended filtering

Payload: `'or'1'!='sahin@sahinyes.com`

## Impact
This vulnerability allows attackers to bypass query logic and potentially retrieve unauthorized data from the database, which could include sensitive user information or administrative credentials.

## Mitigation
1. Use parameterized queries or prepared statements
2. Implement proper input validation to reject SQL metacharacters
3. Employ allowlists for input validation where possible
4. Regularly review and test applications for injection vulnerabilities

---

[← Previous](./sql-injection-1.md) | [Next →](./sql-injection-3.md)



