# Poor Data Validation 1

## Description
In this challenge, you can obtain the result key by exploiting poor data validation to buy oranges for free. The application fails to properly validate user input, allowing manipulation of product quantities.

## Solution
The vulnerability exists because the application does not validate that product quantities are positive numbers. Users can manipulate the input by providing negative values, which breaks the application's logic and allows them to buy products for free.

## Steps to Reproduce

### Step 1
Set the banana quantity to -200 to buy one orange for free.

![](/writeups/assets/images/poor/poor-1.jpg)

## Exploit
This vulnerability demonstrates poor input validation where the application fails to validate that numeric inputs are within acceptable ranges. The exploit works because:

1. The application accepts negative numbers for product quantities
2. The pricing logic does not account for negative quantities
3. Negative quantities effectively reduce the total cost, allowing free purchases
4. There are no bounds checks or validation on input values

The vulnerability allows an attacker to:
1. Purchase products for free by using negative quantities
2. Manipulate the total cost calculation
3. Potentially cause unexpected behavior in the application's financial logic

## Impact
Poor data validation can lead to several serious issues:

1. **Financial Loss**: Customers can obtain products without paying the proper amount
2. **Inventory Issues**: Incorrect tracking of product quantities and sales
3. **Business Logic Abuse**: Exploitation of flawed calculations for personal gain
4. **Data Integrity Problems**: Inconsistent financial records and reporting
5. **Reputational Damage**: Loss of customer trust when security flaws are discovered

## Mitigation
To prevent poor data validation vulnerabilities:

1. **Implement Input Validation**: Validate all user inputs to ensure they meet expected criteria
2. **Use Bounds Checking**: Ensure numeric inputs are within acceptable ranges
3. **Enforce Positive Values**: For quantities and prices, only accept positive numbers
4. **Apply Server-Side Validation**: Never rely solely on client-side validation
5. **Use Strong Typing**: Implement proper data types and constraints in the application
6. **Regular Security Testing**: Include input validation testing in security assessments
7. **Follow Secure Coding Practices**: Adopt standards and guidelines for input handling

---

[Next →](./poor-data-validation-2.md)