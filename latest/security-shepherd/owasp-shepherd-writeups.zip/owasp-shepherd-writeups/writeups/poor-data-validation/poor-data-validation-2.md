# Poor Data Validation 2

## Description
In this challenge, you can obtain the result key by exploiting poor data validation to buy oranges for free. The application fails to properly validate user input, allowing manipulation of product quantities through integer overflow.

## Solution
This challenge demonstrates an integer overflow vulnerability caused by poor data validation. By setting the apple quantity to `999999` and orange quantity to `999999999`, we can exploit the application's failure to handle large numbers properly.

## Steps to Reproduce

### Step 1
Set the apple quantity to `999999` and orange quantity to `999999999` to exploit the integer overflow.

![](/writeups/assets/images/poor/poor-2.jpg)

### Step 2
Submit the order to trigger the integer overflow condition.

### Step 3
Observe the unexpected behavior that results from the overflow, which may reveal the result key.

## Exploit
This vulnerability demonstrates integer overflow caused by poor data validation. The exploit works because:

1. The application does not validate that numeric inputs are within the acceptable range for the data type
2. Large numbers can cause integer overflow, wrapping around to negative values or zero
3. The pricing logic does not account for overflow conditions
4. There are no bounds checks or validation on input values

The vulnerability allows an attacker to:
1. Cause unexpected behavior in calculations through integer overflow
2. Potentially bypass payment requirements
3. Manipulate the application's financial logic
4. Trigger errors or unexpected states in the application

## Impact
Integer overflow vulnerabilities due to poor data validation can lead to serious issues:

1. **Financial Manipulation**: Exploitation of calculation errors for financial gain
2. **System Instability**: Crashes or unexpected behavior due to overflow conditions
3. **Security Bypass**: Potential bypass of payment or access control mechanisms
4. **Data Corruption**: Inconsistent data states due to overflow conditions
5. **Compliance Issues**: Violation of financial industry standards and regulations

## Mitigation
To prevent integer overflow vulnerabilities caused by poor data validation:

1. **Implement Range Validation**: Check that numeric inputs are within acceptable bounds for the data type
2. **Use Safe Arithmetic Libraries**: Employ libraries that detect and prevent overflow conditions
3. **Apply Input Sanitization**: Validate all user inputs before processing
4. **Perform Server-Side Validation**: Never rely solely on client-side validation
5. **Use Larger Data Types**: Where appropriate, use larger data types to reduce overflow risk
6. **Implement Error Handling**: Properly handle overflow conditions when they occur
7. **Regular Security Testing**: Include boundary value testing in security assessments
8. **Follow Secure Coding Practices**: Adopt standards and guidelines for numeric input handling

---

[← Previous](./poor-data-validation-1.md)

