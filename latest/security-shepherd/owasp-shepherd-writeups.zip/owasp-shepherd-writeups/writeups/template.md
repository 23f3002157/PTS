# Challenge name 


## Description
Brief summary of the challenge and what is being tested.


## Solution
Brief summary of the challenge and what is being tested.


## Steps to Reproduce

### 1 Step 

### 2 Step 

### 3 Step 


## Exploit
Describe the exploit and provide payloads or screenshots if needed.

## Impact
Explain the impact of the vulnerability.

## Mitigation
How to fix or prevent the issue.

---

[← Previous](./previous-page.md) | [Next →](./next-page.md)

