# Failure to Restrict URL Access 2

## Description
An administrator of this sub-application would have no issue finding the result key for this level. However, as a guest user, you won't see the simple button that administrators can click.

## Solution
By examining the page's source code and searching for the keyword "admin", you can identify the endpoint and payload needed to send to the server to gain administrator access.

## Steps to Reproduce

### Step 1

View the page's source code and search for the "admin" keyword. In the eval code, you'll find the information needed to exploit this vulnerability.

![](/writeups/assets/images/restrict-url/url-2-1.jpg)

### Step 2

Update the request that was triggered by `Get Guest Info` with this information to obtain the flag.

![](/writeups/assets/images/restrict-url/url-2-2.jpg)

## Exploit
This vulnerability occurs because sensitive information is exposed in the client-side code. By viewing the source code, users can discover hidden administrative endpoints and payloads.

Payload: Use the information found in the source code to modify your request and access administrative functionality.

## Impact
This vulnerability allows unauthorized users to access administrative functions by simply viewing the page source, potentially leading to unauthorized access to sensitive data and system functions.

## Mitigation
1. Never expose sensitive information or administrative endpoints in client-side code
2. Implement proper server-side access controls
3. Use secure coding practices to prevent information leakage
4. Regularly audit client-side code for sensitive information exposure

---

[← Previous](./failure-to-restrict-url-access-1.md) | [Next →](./failure-to-restrict-url-access-3.md)

