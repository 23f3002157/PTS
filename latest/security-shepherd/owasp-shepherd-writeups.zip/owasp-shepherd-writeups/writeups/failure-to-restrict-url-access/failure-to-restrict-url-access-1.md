# Failure to Restrict URL Access 1

## Description
To recover the result key for this challenge, you need to obtain the current server status message from an administrator's point of view.

Use the form provided to view the status of the server.

## Solution
When you click the `Get Server Status` button, it triggers a POST request that sends `userData=123456` to an endpoint. By modifying the endpoint to include "2", we can achieve an administrator view.

## Steps to Reproduce

### Step 1

Open your browser's developer tools (Firefox is used in this example) and click the `Get Server Status` button to intercept the request. Then open the edit page as shown in the picture below.

![](/writeups/assets/images/restrict-url/url-1-1.jpg)

### Step 2

Update the URL endpoint by adding "2" and send the request again. The server will respond with the challenge key.

![](/writeups/assets/images/restrict-url/url-1-2.jpg)

## Exploit
This vulnerability occurs because the application doesn't properly restrict access to administrative endpoints. By simply modifying the URL, a regular user can access administrator functionality.

Payload: Change the endpoint URL to include "2" to access the admin view.

## Impact
This vulnerability allows unauthorized users to access sensitive administrative functions and retrieve confidential information that should only be available to administrators.

## Mitigation
1. Implement proper access controls to ensure only authorized users can access administrative endpoints
2. Use role-based access control (RBAC) to enforce user permissions
3. Validate user permissions on the server side before processing requests
4. Avoid exposing administrative endpoints through predictable URL patterns

---

[Next →](./failure-to-restrict-url-access-2.md)

