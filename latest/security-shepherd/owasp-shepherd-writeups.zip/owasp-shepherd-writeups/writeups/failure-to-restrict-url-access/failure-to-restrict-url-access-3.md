# Failure to Restrict URL Access 3

## Description
Only highly privileged admin users of this sub-application should be able to retrieve the result key.

## Solution
First, we need to exploit the SQL injection vulnerability in the `currentPerson` cookie. Then, we'll change our ID by modifying the `currentPerson` value to that of another user: `MrJohnReillyTheSecond`.

## Steps to Reproduce

### Step 1

First, trigger the `Admin Only Button` and intercept the request using Burp Suite or another web proxy tool.

![](/writeups/assets/images/restrict-url/url-3-1.jpg)

### Step 2

The `currentPerson` cookie has an SQL injection vulnerability. To exploit this, we need to add "UserList" to the URL path.

![](/writeups/assets/images/restrict-url/url-3-2.jpg)

We successfully dumped other users' usernames.

### Step 3

Now we must change the `currentPerson` value to the base64-encoded "MrJohnReillyTheSecond" username to obtain the flag.

![](/writeups/assets/images/restrict-url/url-3-3.jpg)

## Exploit
This vulnerability combines two issues:
1. Failure to restrict URL access to sensitive functionality
2. SQL injection in the `currentPerson` cookie

By adding "UserList" to the URL path, we can enumerate users. Then, by changing our `currentPerson` cookie to a base64-encoded username of another user, we can impersonate them and gain unauthorized access.

## Impact
This vulnerability allows unauthorized users to:
1. Enumerate other users in the system
2. Impersonate other users by modifying their session cookie
3. Gain unauthorized access to sensitive data and functionality

## Mitigation
1. Implement proper access controls on all endpoints
2. Validate and sanitize all user inputs, especially cookies
3. Use parameterized queries to prevent SQL injection
4. Implement proper session management and user authentication
5. Regularly audit application endpoints for proper access controls

---

[← Previous](./failure-to-restrict-url-access-2.md)
