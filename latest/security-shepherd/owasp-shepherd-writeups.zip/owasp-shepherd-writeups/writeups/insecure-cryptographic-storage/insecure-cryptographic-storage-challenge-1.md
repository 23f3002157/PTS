# Insecure Cryptographic Storage Challenge 1

## Description
The result key has been encrypted to ensure that nobody can finish the challenge without knowing the secret key to decrypt it. However, the result key has been encrypted with a famous, but easily broken, Roman cipher. The plain text is in English.

* Encrypted code:

    ```
    Ymj wjxzqy pjd ktw ymnx qjxxts nx ymj ktqqtbnsl xywnsl; rdqtajqdmtwxjwzssnslymwtzlmymjknjqibmjwjfwjdtzltnslbnymdtzwgnlf
    ```

## Solution
The encrypted text uses a Caesar cipher, which is a simple substitution cipher where each letter is shifted by a fixed number of positions in the alphabet. This cipher can be easily broken using brute force since there are only 25 possible shifts.

To decrypt the code, go to the webpage https://www.dcode.fr/caesar-cipher and use the brute force decryption feature.

![](/writeups/assets/images/insecure/insecure-1.jpg)

Decrypted output:
```mylovelyhorserunningthroughthefieldwhereareyougoingwithyourbiga```

## Steps to Reproduce

### Step 1
Navigate to https://www.dcode.fr/caesar-cipher in your web browser.

### Step 2
Paste the encrypted text into the input field and use the brute force decryption option.

### Step 3
Identify the correct decryption (shift of 5) which reveals the readable text.

## Exploit
The vulnerability in this challenge is the use of a weak cryptographic algorithm - the Caesar cipher. This cipher is vulnerable because:

1. It has a very small keyspace (only 25 possible shifts)
2. It preserves the frequency distribution of letters in the original text
3. It can be easily broken using brute force or frequency analysis

The Caesar cipher is not suitable for protecting sensitive data as it provides no real security.

## Impact
Using weak cryptographic algorithms like the Caesar cipher can lead to:
1. Unauthorized access to sensitive data
2. Exposure of confidential information
3. Complete compromise of systems relying on such weak encryption

## Mitigation
1. Use strong, industry-standard encryption algorithms such as AES
2. Implement proper key management practices
3. Ensure encryption keys are sufficiently long and random
4. Regularly update cryptographic libraries and algorithms
5. Follow cryptographic best practices and standards

---

[Next →](./insecure-cryptographic-storage-challenge-2.md)

