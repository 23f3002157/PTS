# Insecure Cryptographic Storage Challenge 2

## Description
The result key has been encrypted to ensure that nobody can finish the challenge without knowing the secret key to decrypt it. The following form can be used to check if you have the correct result key.

## Solution
Examine the page's source code to find the script responsible for encryption. By manipulating this script, we can reverse the encryption process to obtain the key.

## Steps to Reproduce

### Step 1
Find the script responsible for encryption by searching for the keyword `currentCharValue` in the page source code. Copy and paste this script into your browser's console.

![](/writeups/assets/images/insecure/insecure-2-1.jpg)

### Step 2
After pasting the script into your console, modify the encryption operation to perform decryption instead. 

Change:
`currentCharValue += theAlphabet.indexOf(theKey.charAt(theKeysCurrentIndex));`

to:
`currentCharValue -= theAlphabet.indexOf(theKey.charAt(theKeysCurrentIndex));`

Then run the modified script.

![](/writeups/assets/images/insecure/insecure-2-4.jpg)

### Step 3
Finally, submit the decrypted key to complete the challenge.

![](/writeups/assets/images/insecure/insecure-2-2.jpg)

![](/writeups/assets/images/insecure/insecure-2-3.jpg)

Decrypted Output: ``TheVigenereCipherIsAmethodOfEncryptingAlphabeticTextByUsingPoly``

## Exploit
This vulnerability demonstrates client-side security through obscurity, which is not a valid security practice. The encryption algorithm (Vigenère cipher) and implementation are visible in the client-side JavaScript code, making it possible to:

1. Reverse engineer the encryption process
2. Modify the algorithm to perform decryption instead
3. Extract sensitive data that should have remained protected

The Vigenère cipher, while more secure than the Caesar cipher, can still be broken using techniques like Kasiski examination or frequency analysis.

## Impact
Implementing cryptographic operations on the client side with visible algorithms exposes:
1. Sensitive data to unauthorized access
2. Encryption keys or methods to potential attackers
3. Systems to reverse engineering and manipulation

## Mitigation
1. Perform encryption and decryption operations on the server side
2. Use strong, industry-standard encryption algorithms
3. Protect sensitive cryptographic code from exposure
4. Implement proper key management practices
5. Never rely on client-side security for protecting sensitive data

---

[← Previous](./insecure-cryptographic-storage-challenge-1.md) | [Next →](./insecure-cryptographic-storage-challenge-3.md)

