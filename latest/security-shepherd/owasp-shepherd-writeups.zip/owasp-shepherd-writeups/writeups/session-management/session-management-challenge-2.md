# Session Management Challenge Two

## Description
Only an admin of the following sub-application can retrieve the result key to this challenge. This challenge demonstrates how poor password reset implementation can lead to account takeover.

## Solution
This challenge exploits a vulnerability in the password reset functionality. After attempting to log in with a false password, the application reveals the admin email address. Using this email, we can trigger the password reset process, which conveniently returns the new password in the response.

## Steps to Reproduce

### Step 1
Attempt to log in once for the admin user with a false password. The application will return the admin's email address.

### Step 2
Enter this email address in the password reset field and send the request.

### Step 3
Check the password reset request in your browser's network tab and examine the response. The response will contain the newly set password for the admin account.

![](/writeups/assets/images/session/session-2.jpg)

## Exploit
This vulnerability demonstrates poor implementation of the password reset functionality. The exploit works because:

1. The application reveals the admin email address after a failed login attempt
2. The password reset process generates a new password and returns it directly in the response
3. There are no additional verification steps (like sending a reset link to the registered email)
4. The system essentially provides a way to reset any user's password without proper authentication

The vulnerability allows an attacker to:
1. Enumerate valid email addresses through failed login attempts
2. Reset passwords for any account without proper verification
3. Gain unauthorized access to administrative accounts

## Impact
Poor password reset implementation can lead to serious security issues:

1. **Account Takeover**: Attackers can gain unauthorized access to any user account
2. **Privilege Escalation**: Access to administrative accounts with elevated privileges
3. **Data Breach**: Unauthorized access to sensitive information
4. **Identity Theft**: Ability to impersonate users
5. **Reputational Damage**: Loss of user trust when security flaws are discovered

## Mitigation
To prevent password reset vulnerabilities:

1. **Proper Verification**: Send password reset links to the registered email address rather than generating passwords
2. **Rate Limiting**: Implement rate limiting on password reset requests
3. **Information Hiding**: Do not reveal whether an email address exists in the system
4. **Secure Tokens**: Use cryptographically secure, time-limited reset tokens
5. **Multi-Factor Authentication**: Implement additional verification for sensitive accounts
6. **Logging and Monitoring**: Track password reset attempts for suspicious activity
7. **Regular Security Testing**: Include password reset testing in security assessments

---

[← Previous](./session-management-challenge-1.md) | [Next →](./session-management-challenge-3.md)

