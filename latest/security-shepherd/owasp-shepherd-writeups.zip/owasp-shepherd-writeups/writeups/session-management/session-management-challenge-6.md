# Session Management Challenge 6

## Description
To complete this challenge you must sign in as one of the users with a privileged user role. This challenge demonstrates how SQL injection vulnerabilities can be exploited to extract sensitive account information for account takeover.

## Solution
To gain access to the user account, we need to exploit an SQL injection vulnerability that allows us to extract the admin email and answer to the security question.

## Steps to Reproduce

### Step 1
Put a random email to get the security question. Capture that request in your browser console's network tab.

![](/writeups/assets/images/session/session-6-2.jpg)

Copy and paste the request somewhere to edit. It will look something like this:

```
https://localhost/challenges/b5e1020e3742cf2c0880d4098146c4dde25ebd8ceab51807bad88ff47c316eceSecretQuestion?subEmail=sahinyes
```

### Step 2
Now we have an endpoint that is vulnerable to SQL injection. We need to extract the email and security question answer.

* Email SQL injection payload:

Change the `subEmail` parameter value to:
`%22%20UNION%20SELECT%20userAddress%20FROM%20users%20WHERE%20userName%3d%22root`

* Security question answer payload:

Change the `subEmail` parameter value to:
`%22%20UNION%20SELECT%20secretAnswer%20FROM%20users%20WHERE%20userName%3d%22root`

Paste these URLs in your browser to get the information for the admin account.

![](/writeups/assets/images/session/session-6-3.jpg)
![](/writeups/assets/images/session/session-6-4.jpg)

### Step 3
After obtaining the information, log in as the admin user.

![](/writeups/assets/images/session/session-6-1.jpg)

## Exploit
This vulnerability demonstrates how SQL injection can be used to extract sensitive account information for account takeover. The exploit works because:

1. The application is vulnerable to SQL injection in the security question endpoint
2. Attackers can use UNION-based SQL injection to extract data from the users table
3. By querying for the admin user's email address and security question answer, attackers can bypass authentication
4. The application does not properly validate or sanitize user inputs in SQL queries

The vulnerability allows an attacker to:
1. Extract sensitive user information from the database
2. Bypass authentication by obtaining security question answers
3. Gain unauthorized access to administrative accounts
4. Access sensitive data and functionality reserved for privileged users

## Impact
SQL injection vulnerabilities can lead to serious security issues:

1. **Data Breach**: Unauthorized access to sensitive user information in the database
2. **Account Takeover**: Ability to bypass authentication and gain access to any account
3. **Privilege Escalation**: Access to administrative accounts with elevated privileges
4. **Data Manipulation**: Ability to modify or delete data in the database
5. **System Compromise**: Potential for complete system takeover through database access
6. **Reputational Damage**: Loss of user trust when security flaws are discovered

## Mitigation
To prevent SQL injection vulnerabilities:

1. **Parameterized Queries**: Use parameterized queries or prepared statements for all database interactions
2. **Input Validation**: Validate and sanitize all user inputs
3. **Principle of Least Privilege**: Ensure database accounts have minimal necessary permissions
4. **Web Application Firewall**: Implement a WAF to detect and block SQL injection attempts
5. **Regular Security Testing**: Include SQL injection testing in security assessments
6. **Secure Coding Practices**: Follow secure coding standards and guidelines
7. **Database Monitoring**: Monitor database queries for suspicious activity

---

[← Previous](./session-management-challenge-5.md) | [Next →](./session-management-challenge-7.md)
