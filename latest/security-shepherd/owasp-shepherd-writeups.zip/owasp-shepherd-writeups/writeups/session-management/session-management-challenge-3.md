# Session Management Challenge Three

## Description
Only an admin of the following sub-application can retrieve the result key to this challenge. You have been granted user privileges because the admins need somebody to boss around. This challenge demonstrates how session cookies can be manipulated to impersonate other users.

## Solution
This challenge exploits a vulnerability in the "New Password" function. The "current" cookie determines which user's password is being changed. By manipulating this cookie, users can set a new password for the admin account.

## Steps to Reproduce

### Step 1
Send an example "New Password" request and send it to Burp Suite's repeater. Alternatively, if using your browser, go to your console's storage > cookie tab and change the `current` cookie value to `WVdSdGFXND0=` (which is the base64-encoded string "YWRmG4") and log in to the admin account with the new password.

### Step 2
With Burp Suite, select the "current" cookie value and replace it with the admin identifier. For example, change it to the value that represents the admin user, then attempt to log in with the new password.

![](/writeups/assets/images/session/session-3.jpg)

![](/writeups/assets/images/session/session-3-2.jpg)

## Exploit
This vulnerability demonstrates insecure session management where user context is controlled by a client-side cookie that can be easily manipulated. The exploit works because:

1. The application uses a "current" cookie to determine which user's password is being changed
2. The cookie value can be modified by the user to target different accounts
3. `WVdSdGFXND0=` is the base64-encoded string "YWRmG4", which identifies the admin user
4. By changing the cookie to this value, users can set a new password for the admin account
5. The application processes the password change without verifying that the user has permission to change that account's password

The vulnerability allows an attacker to:
1. Impersonate other users by changing their passwords
2. Gain unauthorized access to administrative accounts
3. Bypass access controls by manipulating session context

## Impact
Session manipulation vulnerabilities can lead to serious security issues:

1. **Account Takeover**: Attackers can gain unauthorized access to any user account
2. **Privilege Escalation**: Access to administrative accounts with elevated privileges
3. **Unauthorized Data Access**: Access to sensitive information belonging to other users
4. **Data Manipulation**: Ability to modify or delete data belonging to other users
5. **Reputational Damage**: Loss of user trust when security flaws are discovered

## Mitigation
To prevent session manipulation vulnerabilities:

1. **Server-Side User Context**: Store user context information on the server rather than in client-side cookies
2. **Authorization Checks**: Verify that users have permission to perform actions on specific accounts
3. **Session Validation**: Validate session integrity and user permissions on the server for every request
4. **Secure Session Tokens**: Use cryptographically secure session identifiers that cannot be easily guessed
5. **Input Validation**: Validate all user inputs, including cookie values
6. **Regular Security Testing**: Include session management testing in security assessments
7. **Follow Secure Coding Practices**: Adopt standards and guidelines for secure session management

---

[← Previous](./session-management-challenge-2.md) | [Next →](./session-management-challenge-4.md)

