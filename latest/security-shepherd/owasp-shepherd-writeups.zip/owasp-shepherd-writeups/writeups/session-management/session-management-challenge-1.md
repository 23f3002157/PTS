# Session Management Challenge One

## Description
Only administrators of the following sub-application can retrieve the result key. This challenge demonstrates how session management vulnerabilities can allow privilege escalation by manipulating authorization cookies.

## Solution
This challenge demonstrates a session management vulnerability where user authorization is controlled by a checksum cookie that can be manipulated. By intercepting the request triggered by the `Administrator Only Button` and changing the cookie value from user to administrator, we can escalate our privileges.

## Steps to Reproduce

### Step 1
Trigger the `Administrator Only Button` and send the request to Burp Suite's repeater for modification.

![](/writeups/assets/images/session/session-1-2.jpg)

### Step 2
Change the `checksum` cookie value to `dXNlclJvbGU9YWRtaW5pc3RyYXRvcg==` (which is the base64-encoded string "userRole=administrator") and send the request again. You will receive the result key.

![](/writeups/assets/images/session/session-1.jpg)

## Exploit
This vulnerability demonstrates insecure session management where authorization is determined by a client-side cookie that can be easily manipulated. The exploit works because:

1. The application stores user role information in a client-side cookie
2. The cookie value `dXNlclJvbGU9dXNlcg==` decodes to "userRole=user"
3. By changing it to `dXNlclJvbGU9YWRtaW5pc3RyYXRvcg==`, which decodes to "userRole=administrator", we can escalate our privileges
4. The application trusts the client-side cookie without server-side validation

The vulnerability allows an attacker to:
1. Escalate privileges from regular user to administrator
2. Access sensitive functionality and data reserved for administrators
3. Bypass access controls entirely

## Impact
Insecure session management can lead to serious security issues:

1. **Privilege Escalation**: Attackers can gain unauthorized access to administrative functions
2. **Unauthorized Data Access**: Access to sensitive information that should be protected
3. **System Compromise**: Potential for complete system takeover through administrative access
4. **Data Manipulation**: Ability to modify or delete critical system data
5. **Reputational Damage**: Loss of user trust when security flaws are discovered

## Mitigation
To prevent session management vulnerabilities:

1. **Server-Side Session Storage**: Store session data on the server rather than in client-side cookies
2. **Session Validation**: Validate session integrity and user permissions on the server for every request
3. **Secure Session Tokens**: Use cryptographically secure, random session identifiers
4. **Session Expiration**: Implement proper session timeout and invalidation mechanisms
5. **Role-Based Access Control**: Verify user permissions on the server side for all sensitive operations
6. **Regular Security Testing**: Include session management testing in security assessments
7. **Follow Secure Coding Practices**: Adopt standards and guidelines for session management

---

[Next →](./session-management-challenge-2.md)

