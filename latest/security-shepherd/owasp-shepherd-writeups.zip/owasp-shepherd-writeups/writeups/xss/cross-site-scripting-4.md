# Cross Site Scripting 4

## Description
This challenge involves finding a Cross-Site Scripting (XSS) vulnerability in a form with input filtering. This challenge demonstrates how attackers can bypass filtering by injecting attributes into URL fields.

## Solution
The challenge demonstrates a technique for bypassing input filtering in URL fields by injecting HTML attributes. The filtering mechanism appears to allow URLs but fails to prevent HTML attribute injection.

## Steps to Reproduce

### Step 1
Identify input fields that accept URLs where XSS might be possible.

### Step 2
Use the provided payload to exploit the vulnerability:

```html
http://xss" OnmOuseover=alert(123);//
```

### Step 3
Submit the payload and observe the execution of the JavaScript alert when the mouse hovers over the element.

![](/writeups/assets/images/xss/xss-4.jpg)

## Exploit
This vulnerability demonstrates how attackers can bypass URL filtering by injecting HTML attributes. The exploit works by:

1. Starting with a valid URL prefix (`http://xss`)
2. Breaking out of the URL attribute with a double quote (`"`)
3. Injecting a new HTML attribute (`OnmOuseover=alert(123);//`)
4. Using mixed case (`OnmOuseover`) to potentially bypass case-sensitive filters
5. Adding a comment (`//`) to neutralize any remaining code
6. When the mouse hovers over the element, the JavaScript alert executes

This shows how attackers can exploit weaknesses in URL validation to inject malicious attributes.

## Impact
XSS vulnerabilities can lead to serious security issues:

1. **Session Hijacking**: Attackers can steal session cookies and impersonate users
2. **Data Theft**: Sensitive information can be extracted from the victim's browser
3. **Account Compromise**: Attackers can perform actions as the victim, potentially changing passwords or settings
4. **Malware Distribution**: Victims can be redirected to malicious websites that distribute malware
5. **Phishing Attacks**: Attackers can manipulate the appearance of trusted websites to steal credentials
6. **Reputational Damage**: Loss of user trust when security flaws are discovered

## Mitigation
To prevent XSS vulnerabilities in URL fields:

1. **URL Validation**: Implement proper URL validation that ensures inputs conform to valid URL formats
2. **Attribute Filtering**: Prevent HTML attribute injection in URL fields
3. **Context-Aware Encoding**: Encode data based on the context where it will be rendered
4. **Content Security Policy (CSP)**: Implement strict CSP headers to limit script execution
5. **Input Sanitization**: Sanitize user inputs to remove or escape potentially dangerous characters
6. **Regular Security Testing**: Include XSS testing in security assessments with various injection techniques
7. **Security Headers**: Implement appropriate security headers like X-XSS-Protection

---

[← Previous](./cross-site-scripting-3.md) | [Next →](./cross-site-scripting-5.md)


