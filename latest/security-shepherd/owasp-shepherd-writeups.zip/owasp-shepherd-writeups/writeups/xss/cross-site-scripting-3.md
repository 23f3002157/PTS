# Cross Site Scripting 3

## Description
This challenge involves finding a Cross-Site Scripting (XSS) vulnerability in a form with input filtering. This challenge demonstrates how attackers can bypass filtering by using variations of event handler names.

## Solution
The challenge demonstrates a technique for bypassing input filtering by using repeated or modified event handler names. The filtering mechanism appears to be looking for specific patterns but can be bypassed with creative variations.

## Steps to Reproduce

### Step 1
Analyze the form and identify input fields where XSS might be possible.

### Step 2
Use the provided payload to exploit the vulnerability:

```html
<input type="button" oncliconcliconclickkk="alert('XSS')">
```

### Step 3
Submit the payload and observe the execution of the JavaScript alert when the button is clicked.

![](/writeups/assets/images/xss/xss-3.jpg)

## Exploit
This vulnerability demonstrates a common bypass technique for XSS filters that rely on simple pattern matching. The exploit works by:

1. Using a modified event handler name (`oncliconcliconclickkk` instead of `onclick`)
2. The filtering mechanism fails to recognize this variation as a malicious event handler
3. When the button is clicked, the JavaScript alert executes
4. This shows how attackers can evade simple filtering by using variations of known attack vectors

The vulnerability allows an attacker to:
1. Execute arbitrary JavaScript in the victim's browser
2. Bypass simple pattern-based filtering mechanisms
3. Exploit weaknesses in security controls that rely on signature-based detection

## Impact
XSS vulnerabilities can lead to serious security issues:

1. **Session Hijacking**: Attackers can steal session cookies and impersonate users
2. **Data Theft**: Sensitive information can be extracted from the victim's browser
3. **Account Compromise**: Attackers can perform actions as the victim, potentially changing passwords or settings
4. **Malware Distribution**: Victims can be redirected to malicious websites that distribute malware
5. **Phishing Attacks**: Attackers can manipulate the appearance of trusted websites to steal credentials
6. **Reputational Damage**: Loss of user trust when security flaws are discovered

## Mitigation
To prevent XSS vulnerabilities:

1. **Context-Aware Encoding**: Encode data based on the context where it will be rendered (HTML, JavaScript, CSS, URL)
2. **Input Validation**: Validate and sanitize all user inputs using allowlists rather than denylists
3. **Content Security Policy (CSP)**: Implement strict CSP headers to limit script execution
4. **Use Secure Frameworks**: Employ frameworks that automatically escape output
5. **Regular Security Testing**: Include XSS testing in security assessments with various bypass techniques
6. **Security Headers**: Implement appropriate security headers like X-XSS-Protection
7. **Follow Secure Coding Practices**: Adopt standards and guidelines for preventing XSS

---

[← Previous](./cross-site-scripting-2.md) | [Next →](./cross-site-scripting-4.md)


