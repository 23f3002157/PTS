# Cross Site Scripting 1

## Description
This challenge involves finding a Cross-Site Scripting (XSS) vulnerability in a form where input filtering appears to be implemented. Despite the filtering, there are still ways to inject and execute malicious scripts.

## Solution
The challenge demonstrates that basic input filtering may not be sufficient to prevent XSS attacks. By using the provided payload, we can bypass the filtering mechanism and execute JavaScript in the context of the victim's browser.

## Steps to Reproduce

### Step 1
Analyze the form and identify input fields where XSS might be possible.

### Step 2
Use the provided payload to exploit the vulnerability:

```html
<input type="button" onmouseup="alert('XSS')"/>
```

### Step 3
Submit the payload and observe the execution of the JavaScript alert when the mouse button is released over the button element.

![](/writeups/assets/images/xss/xss-1.jpg)

## Exploit
This vulnerability demonstrates that simple input filtering is insufficient to prevent XSS attacks. The exploit works by:

1. Using an HTML input element with an event handler attribute
2. The `onmouseup` event handler executes JavaScript when the mouse button is released
3. The filtering mechanism fails to block this specific vector
4. The payload executes in the context of the victim's browser session

The vulnerability allows an attacker to:
1. Execute arbitrary JavaScript in the victim's browser
2. Steal session cookies or other sensitive information
3. Perform actions on behalf of the victim
4. Redirect the victim to malicious websites

## Impact
XSS vulnerabilities can lead to serious security issues:

1. **Session Hijacking**: Attackers can steal session cookies and impersonate users
2. **Data Theft**: Sensitive information can be extracted from the victim's browser
3. **Account Compromise**: Attackers can perform actions as the victim, potentially changing passwords or settings
4. **Malware Distribution**: Victims can be redirected to malicious websites that distribute malware
5. **Phishing Attacks**: Attackers can manipulate the appearance of trusted websites to steal credentials
6. **Reputational Damage**: Loss of user trust when security flaws are discovered

## Mitigation
To prevent XSS vulnerabilities:

1. **Input Validation**: Validate and sanitize all user inputs
2. **Output Encoding**: Encode data before rendering it in HTML, JavaScript, CSS, or URL contexts
3. **Content Security Policy (CSP)**: Implement strict CSP headers to limit script execution
4. **Use Secure Frameworks**: Employ frameworks that automatically escape output
5. **Regular Security Testing**: Include XSS testing in security assessments
6. **Security Headers**: Implement appropriate security headers like X-XSS-Protection
7. **Follow Secure Coding Practices**: Adopt standards and guidelines for preventing XSS

---

[Next →](./cross-site-scripting-2.md)