# Cross Site Request Forgery Challenge One

## Description
To complete this challenge, you must get your CSRF counter above 0. The request to increment your counter is:

`GET /user/csrfchallengeone/plusplus?userid=your_user_id`

You need to craft a payload that, when visited by another user, will automatically trigger this request using their session. This can be done by embedding the request as the source of an image tag.

## Solution
This challenge demonstrates a simple CSRF vulnerability where a GET request can be triggered without user interaction. By crafting a malicious image tag with the target URL, we can force other users to unknowingly increment our counter.

## Steps to Reproduce

### 1 Step
Identify your user ID. In this example, the user ID is `d1ad0ecec51f6e1e7ea4ff97d9a106a3437a66f5`.

### 2 Step
Construct the full URL by combining the path with your user ID:
```
https://localhost/user/csrfchallengeone/plusplus?userid=d1ad0ecec51f6e1e7ea4ff97d9a106a3437a66f5
```

### 3 Step
Embed the constructed URL in a post message field as an image source. When someone views the post, the image request will trigger the CSRF attack.

⚠️ Ensure you update the hostname and your user ID in the payload.

## Exploit
Embed the constructed URL in a post message field using an image tag:
```html
https://<domain>>/user/csrfchallengeone/plusplus?userid=<userId>
```

When someone views the post, the browser will automatically make the request to increment the counter.

![](/writeups/assets/images/csrf/csrf-1.jpg)

## Impact
This vulnerability allows an attacker to perform actions on behalf of another user without their consent, potentially leading to unauthorized changes or data exposure.

## Mitigation
To prevent CSRF attacks:
- Implement anti-CSRF tokens in forms and validate them on the server side
- Use SameSite cookies to prevent cross-site requests
- Implement Content Security Policy (CSP) headers to restrict resource loading
- Consider using the double-submit cookie pattern for stateless CSRF protection

---

[← Previous](./csrf-7.md) | [Next →](./csrf-2.md)

