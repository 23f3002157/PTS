<p align="center">
  <img src="https://owaspsamm.org//img/owasp_logo_1c_w_notext.png" alt="OWASP Logo">
</p>

<h1 align="center">Security Shepherd</h1>

<p align="center">
    <a href="https://owasp.org/www-project-security-shepherd/">📝 Project Page</a>
    &nbsp;&nbsp;&nbsp;
    <a href="https://github.com/OWASP/SecurityShepherd/">🏗️ GitHub Repo</a>
</p>


<br>

<div align="center">

|Topic|Problem Sets|
|-----------|----|
|CSRF | [Cross Site Request Forgery Challenge 1](writeups/csrf/csrf-1.md)<br>[Cross Site Request Forgery Challenge 2](writeups/csrf/csrf-2.md)<br>[Cross Site Request Forgery Challenge 3](writeups/csrf/csrf-3.md)<br>[Cross Site Request Forgery Challenge 4](writeups/csrf/csrf-4.md)<br>[Cross Site Request Forgery Challenge 5](writeups/csrf/csrf-5.md)<br>[Cross Site Request Forgery Challenge 6](writeups/csrf/csrf-6.md)<br>[Cross Site Request Forgery Challenge 7](writeups/csrf/csrf-7.md)<br>[Cross Site Request Forgery Challenge JSON](writeups/csrf/csrf-json.md)|
|Failure to Restrict URL Access| [Failure to Restrict URL Access 1](writeups/failure-to-restrict-url-access/failure-to-restrict-url-access-1.md)<br>[Failure to Restrict URL Access 2](writeups/failure-to-restrict-url-access/failure-to-restrict-url-access-2.md)<br>[Failure to Restrict URL Access 3](writeups/failure-to-restrict-url-access/failure-to-restrict-url-access-3.md)|
|Injection| [NoSQL Injection One](writeups/injection/nosql-injection-one.md)<br>[SQL Injection 1](writeups/injection/sql-injection-1.md)<br>[SQL Injection 2](writeups/injection/sql-injection-2.md)<br>[SQL Injection 3](writeups/injection/sql-injection-3.md)<br>[SQL Injection 4](writeups/injection/sql-injection-4.md)<br>[SQL Injection 5](writeups/injection/sql-injection-5.md)<br>[SQL Injection 6](writeups/injection/sql-injection-6.md)<br>[SQL Injection 7](writeups/injection/sql-injection-7.md)<br>[SQL Injection Escaping](writeups/injection/sql-injection-escaping.md)<br>[SQL Injection Stored Procedure](writeups/injection/sql-injection-stored-procedure.md)|
|Insecure Cryptographic Storage| [Insecure Cryptographic Storage Challenge 1](writeups/insecure-cryptographic-storage/insecure-cryptographic-storage-challenge-1.md)<br>[Insecure Cryptographic Storage Challenge 2](writeups/insecure-cryptographic-storage/insecure-cryptographic-storage-challenge-2.md)<br>[Insecure Cryptographic Storage Challenge 3](writeups/insecure-cryptographic-storage/insecure-cryptographic-storage-challenge-3.md)<br>
|Insecure Direct Object References| [Insecure Direct Object Reference Bank](writeups/insecure-direct-object-references/insecure-direct-object-reference-bank.md)<br>[Insecure Direct Object Reference Challenge 1](writeups/insecure-direct-object-references/insecure-direct-object-reference-challenge-1.md)<br>[Insecure Direct Object Reference Challenge 2](writeups/insecure-direct-object-references/insecure-direct-object-reference-challenge-2.md)|
|Poor Data Validation| [Poor Data Validation 1](writeups/poor-data-validation/poor-data-validation-1.md)<br>[Poor Data Validation 2](writeups/poor-data-validation/poor-data-validation-2.md)|
|Session Management| [Session Management Challenge 1](writeups/session-management/session-management-challenge-1.md)<br>[Session Management Challenge 2](writeups/session-management/session-management-challenge-2.md)<br>[Session Management Challenge 3](writeups/session-management/session-management-challenge-3.md)<br>[Session Management Challenge 4](writeups/session-management/session-management-challenge-4.md)<br>[Session Management Challenge 5](writeups/session-management/session-management-challenge-5.md)<br>[Session Management Challenge 6](writeups/session-management/session-management-challenge-6.md)<br>[Session Management Challenge 7](writeups/session-management/session-management-challenge-7.md)<br>[Session Management Challenge 8](writeups/session-management/session-management-challenge-8.md)|
|XSS| [Cross Site Scripting 1](writeups/xss/cross-site-scripting-1.md)<br>[Cross Site Scripting 2](writeups/xss/cross-site-scripting-2.md)<br>[Cross Site Scripting 3](writeups/xss/cross-site-scripting-3.md)<br>[Cross Site Scripting 4](writeups/xss/cross-site-scripting-4.md)<br>[Cross Site Scripting 5](writeups/xss/cross-site-scripting-5.md)<br>[Cross Site Scripting 6](writeups/xss/cross-site-scripting-6.md)|
</div>